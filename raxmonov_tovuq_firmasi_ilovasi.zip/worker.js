
const recordForm = document.getElementById("addRecordForm");
const recordList = document.getElementById("recordList");
let records = JSON.parse(localStorage.getItem("records")) || [];

function renderRecords() {
  recordList.innerHTML = "";
  records.forEach((record, index) => {
    recordList.innerHTML += `
      <div class="worker-card">
        <p>🐔 Tovuqlar: ${record.chicken}</p>
        <p>🥚 Tuxum: ${record.egg}</p>
        <p>🌾 Don narxi: ${record.feed} so'm</p>
      </div>
    `;
  });
}

recordForm.addEventListener("submit", function (e) {
  e.preventDefault();
  const chicken = document.getElementById("chicken").value;
  const egg = document.getElementById("egg").value;
  const feed = document.getElementById("feed").value;
  records.push({ chicken, egg, feed });
  localStorage.setItem("records", JSON.stringify(records));
  renderRecords();
  recordForm.reset();
});

renderRecords();
