
const form = document.getElementById("addWorkerForm");
const workersList = document.getElementById("workersList");
let workers = JSON.parse(localStorage.getItem("workers")) || [];

function renderWorkers() {
  workersList.innerHTML = "";
  workers.forEach((worker, index) => {
    workersList.innerHTML += `
      <div class="worker-card">
        <h3>${worker.name} ${worker.surname}</h3>
        <p>📞 ${worker.phone}</p>
        <button onclick="deleteWorker(${index})">❌ O‘chirish</button>
      </div>
    `;
  });
}

function deleteWorker(index) {
  workers.splice(index, 1);
  localStorage.setItem("workers", JSON.stringify(workers));
  renderWorkers();
}

form.addEventListener("submit", function (e) {
  e.preventDefault();
  const name = document.getElementById("name").value;
  const surname = document.getElementById("surname").value;
  const phone = document.getElementById("phone").value;
  workers.push({ name, surname, phone });
  localStorage.setItem("workers", JSON.stringify(workers));
  renderWorkers();
  form.reset();
});

renderWorkers();
