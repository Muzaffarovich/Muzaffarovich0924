
let products = JSON.parse(localStorage.getItem('products')) || [];

function renderProducts() {
  const list = document.getElementById('productList');
  list.innerHTML = '';
  products.forEach((p, index) => {
    const div = document.createElement('div');
    div.className = 'worker-card';
    div.innerHTML = `
      <h3>${p.name}</h3>
      <p>💰 Narxi: ${p.price} so'm / ${p.unit}</p>
      <p>📊 Kunlik sarf: ${p.usage} ${p.unit}</p>
      <button onclick="deleteProduct(${index})">❌ O‘chirish</button>
    `;
    list.appendChild(div);
  });
}

function deleteProduct(index) {
  products.splice(index, 1);
  localStorage.setItem('products', JSON.stringify(products));
  renderProducts();
}

document.getElementById('addProductForm').addEventListener('submit', function (e) {
  e.preventDefault();
  const name = document.getElementById('pName').value;
  const price = parseFloat(document.getElementById('pPrice').value);
  const unit = document.getElementById('pUnit').value;
  const usage = parseFloat(document.getElementById('pUsage').value);

  products.push({ name, price, unit, usage });
  localStorage.setItem('products', JSON.stringify(products));
  renderProducts();
  this.reset();
});

renderProducts();
